


int bitNor(int, int);
int test_bitNor(int, int);
int bitXor(int, int);
int test_bitXor(int, int);
int isNotEqual(int, int);
int test_isNotEqual(int, int);
int getByte(int, int);
int test_getByte(int, int);
int copyLSB(int);
int test_copyLSB(int);
int tmax();
int test_tmax();
int isNonNegative(int);
int test_isNonNegative(int);
